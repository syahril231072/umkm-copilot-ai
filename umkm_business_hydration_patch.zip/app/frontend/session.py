"""
Session Frontend
================

Helper session state untuk Streamlit.
"""

from __future__ import annotations

from typing import Any, Mapping, MutableMapping
from uuid import UUID, uuid4

from app.frontend.api_client import FrontendApiClient


DEFAULT_API_BASE_URL = "http://127.0.0.1:8000"
DEFAULT_BUSINESS_ID = ""
DEFAULT_LIMIT = 1000
DEFAULT_CURRENCY = "IDR"
DEFAULT_TIMEZONE = "Asia/Jakarta"
DEFAULT_LANGUAGE = "Bahasa Indonesia"
DEFAULT_PRODUCT_ID = ""


def ensure_frontend_session(session_state: MutableMapping[str, Any]) -> None:
    """Pastikan semua kunci session tersedia."""

    session_state.setdefault("api_base_url", DEFAULT_API_BASE_URL)
    session_state.setdefault("business_id", DEFAULT_BUSINESS_ID)
    session_state.setdefault("dashboard_limit", DEFAULT_LIMIT)
    session_state.setdefault("business_name", "")
    session_state.setdefault("owner_name", "")
    session_state.setdefault("business_type", "")
    session_state.setdefault("currency", DEFAULT_CURRENCY)
    session_state.setdefault("timezone", DEFAULT_TIMEZONE)
    session_state.setdefault("language", DEFAULT_LANGUAGE)
    session_state.setdefault("active_product_id", DEFAULT_PRODUCT_ID)
    session_state.setdefault("active_product_name", "")
    session_state.setdefault("backend_products", [])
    session_state.setdefault("business_profiles", [])
    session_state.setdefault("business_hydration_attempted", False)

    _ensure_valid_session_id(session_state)


def get_api_client_from_session_state(
    session_state: MutableMapping[str, Any],
) -> FrontendApiClient:
    """Bangun API client dari session state."""

    ensure_frontend_session(session_state)

    return FrontendApiClient(api_base_url=str(session_state["api_base_url"]))


def hydrate_business_from_backend(
    session_state: MutableMapping[str, Any],
    client: FrontendApiClient,
    *,
    force: bool = False,
) -> bool:
    """
    Hydrate business aktif dari backend jika session belum memiliki business_id.

    Returns:
        True jika business_id valid tersedia setelah proses hydrate.
    """

    ensure_frontend_session(session_state)

    current_business_id = str(session_state.get("business_id", "")).strip()
    if _is_valid_uuid(current_business_id) and not force:
        return True

    if session_state.get("business_hydration_attempted") is True and not force:
        return _is_valid_uuid(str(session_state.get("business_id", "")).strip())

    session_state["business_hydration_attempted"] = True

    response = client.list_business_profiles(limit=100)
    if not response.get("success"):
        return False

    profiles = extract_business_profiles_from_response(response)
    session_state["business_profiles"] = profiles

    if not profiles:
        return False

    set_business_from_response(session_state, profiles[0])
    return _is_valid_uuid(str(session_state.get("business_id", "")).strip())


def extract_business_profiles_from_response(
    response: Mapping[str, Any],
) -> list[dict[str, Any]]:
    """Ambil daftar business profile dari berbagai bentuk response backend."""

    data = response.get("data")
    raw_profiles: Any

    if isinstance(data, Mapping):
        raw_profiles = (
            data.get("businesses")
            or data.get("business_profiles")
            or data.get("profiles")
            or data.get("items")
            or []
        )
    elif isinstance(data, list):
        raw_profiles = data
    else:
        raw_profiles = []

    if isinstance(raw_profiles, Mapping):
        raw_profiles = [raw_profiles]

    if not isinstance(raw_profiles, list):
        return []

    profiles: list[dict[str, Any]] = []
    for item in raw_profiles:
        if isinstance(item, Mapping):
            normalized = normalize_business_profile(item)
            if normalized.get("business_id"):
                profiles.append(normalized)

    return profiles


def normalize_business_profile(data: Mapping[str, Any]) -> dict[str, Any]:
    """Normalisasi business profile dari backend."""

    business_id = (
        data.get("business_id")
        or data.get("id")
        or data.get("uuid")
        or ""
    )

    return {
        "business_id": str(business_id).strip(),
        "business_name": str(data.get("business_name") or "").strip(),
        "owner_name": str(data.get("owner_name") or "").strip(),
        "business_type": str(data.get("business_type") or "").strip(),
        "currency": str(data.get("currency") or DEFAULT_CURRENCY).strip(),
        "timezone": str(data.get("timezone") or DEFAULT_TIMEZONE).strip(),
        "language": str(data.get("language") or DEFAULT_LANGUAGE).strip(),
    }


def has_business_profile(session_state: MutableMapping[str, Any]) -> bool:
    """Periksa apakah profil bisnis aktif sudah tersedia."""

    ensure_frontend_session(session_state)

    return _is_valid_uuid(str(session_state.get("business_id", "")).strip())


def has_active_product(session_state: MutableMapping[str, Any]) -> bool:
    """Periksa apakah produk aktif sudah tersedia."""

    ensure_frontend_session(session_state)

    return bool(str(session_state.get("active_product_id", "")).strip())


def build_business_preferences(
    session_state: MutableMapping[str, Any],
) -> dict[str, str]:
    """Bangun preferensi bisnis aktif."""

    ensure_frontend_session(session_state)

    return {
        "business_id": str(session_state.get("business_id", "")).strip(),
        "business_name": str(session_state.get("business_name", "")).strip(),
        "owner_name": str(session_state.get("owner_name", "")).strip(),
        "business_type": str(session_state.get("business_type", "")).strip(),
        "currency": str(session_state.get("currency", DEFAULT_CURRENCY)).strip(),
        "timezone": str(session_state.get("timezone", DEFAULT_TIMEZONE)).strip(),
        "language": str(session_state.get("language", DEFAULT_LANGUAGE)).strip(),
    }


def set_business_from_response(
    session_state: MutableMapping[str, Any],
    data: Mapping[str, Any],
) -> None:
    """Simpan profil bisnis dari response backend."""

    ensure_frontend_session(session_state)
    normalized = normalize_business_profile(data)

    session_state["business_id"] = normalized["business_id"]
    session_state["business_name"] = normalized["business_name"]
    session_state["owner_name"] = normalized["owner_name"]
    session_state["business_type"] = normalized["business_type"]
    session_state["currency"] = normalized["currency"]
    session_state["timezone"] = normalized["timezone"]
    session_state["language"] = normalized["language"]


def set_active_product_from_response(
    session_state: MutableMapping[str, Any],
    data: Mapping[str, Any],
) -> None:
    """Simpan produk aktif dari response backend."""

    ensure_frontend_session(session_state)

    product_id = str(data.get("product_id") or data.get("id") or "").strip()
    product_name = str(
        data.get("name")
        or data.get("product_name")
        or ""
    ).strip()

    session_state["active_product_id"] = product_id
    session_state["active_product_name"] = product_name


def set_backend_products(
    session_state: MutableMapping[str, Any],
    products: list[dict[str, Any]],
) -> None:
    """Simpan daftar produk backend."""

    ensure_frontend_session(session_state)
    session_state["backend_products"] = products


def get_backend_products(
    session_state: MutableMapping[str, Any],
) -> list[dict[str, Any]]:
    """Ambil daftar produk backend."""

    ensure_frontend_session(session_state)
    products = session_state.get("backend_products", [])

    if isinstance(products, list):
        return [dict(product) for product in products if isinstance(product, dict)]

    return []


def build_common_payload(
    session_state: MutableMapping[str, Any],
    extra: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Bangun payload umum untuk endpoint yang membutuhkan konteks bisnis."""

    ensure_frontend_session(session_state)

    payload = {
        "business_id": str(session_state["business_id"]),
        "session_id": str(session_state["session_id"]),
    }

    if extra:
        payload.update(extra)

    return payload


def reset_frontend_session_identity(
    session_state: MutableMapping[str, Any],
) -> None:
    """Buat ulang session_id UUID untuk percakapan baru."""

    session_state["session_id"] = _new_session_id()


def _ensure_valid_session_id(session_state: MutableMapping[str, Any]) -> None:
    """Pastikan session_id adalah UUID valid."""

    current_session_id = str(session_state.get("session_id", "")).strip()

    if not _is_valid_uuid(current_session_id):
        session_state["session_id"] = _new_session_id()


def _new_session_id() -> str:
    """Buat UUID baru untuk session percakapan."""

    return str(uuid4())


def _is_valid_uuid(value: str) -> bool:
    """Periksa UUID."""

    if not value:
        return False

    try:
        UUID(value)
    except (TypeError, ValueError):
        return False

    return True
